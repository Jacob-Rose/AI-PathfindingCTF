// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#define print(x) UE_LOG(LogTemp, Warning, TEXT(#x))

